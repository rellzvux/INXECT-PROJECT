export const firebaseConfig = {
  apiKey: "AIzaSyAbaqHlvyW6cGWYoVwyxjQYx4RdalZFJcs",
  authDomain: "inxect-crash.firebaseapp.com",
  projectId: "inxect-crash",
  storageBucket: "inxect-crash.firebasestorage.app",
  messagingSenderId: "398531403031",
  appId: "1:398531403031:web:3c4d9b23c80381d817eb52",
  measurementId: "G-QY728JVYS8"
};

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
export const app = initializeApp(firebaseConfig);
